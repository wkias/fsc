/*
 * File: iar.h
 * Purpose:	Define constants used by IAR toolchain
 *
 * Notes:
 *
 */

#ifndef _IAR_H_
#define _IAR_H_

/********************************************************************/

/********************************************************************/

#endif /* _IAR_H_ */
