
void config1();
void config2();
void config3();
void param_switcher();
void dynamic_param(void);